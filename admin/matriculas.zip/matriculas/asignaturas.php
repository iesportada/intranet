<?php defined('INTRANET_DIRECTORY') OR exit('No direct script access allowed'); 

// Optativas 1�, 2� y 3� ESO
	$opt1 = array("Alem�n 2� Idioma","Cambios Sociales y G�nero", "Franc�s 2� Idioma","Tecnolog�a Aplicada");
	$opt2 = array("Alem�n 2� Idioma","Cambios Sociales y G�nero", "Franc�s 2� Idioma","M�todos de la Ciencia");
	$opt3 = array("Alem�n 2� Idioma","Cambios Sociales y G�nero", "Franc�s 2� Idioma","Cultura Cl�sica", "Taller T.I.C. III", "Taller de Cer�mica", "Taller de Teatro");
	$a1 = array("Actividades de refuerzo de Lengua Castellana", "Actividades de refuerzo de Matem�ticas", "Actividades de refuerzo de Ingl�s", "Ampliaci�n: Taller T.I.C.", "Ampliaci�n: Taller de Teatro");
	$a2 = array("Actividades de refuerzo de Lengua Castellana ", "Actividades de refuerzo de Matem�ticas", "Actividades de refuerzo de Ingl�s", "Ampliaci�n: Taller T.I.C. II", "Ampliaci�n: Taller de Teatro II");

// Itinerarios 4� ESO	
	$it41 = array("(Bachillerato de Ciencias y Tecnolog�a - V�a de Ciencias de la Naturaleza y la Salud)", "F�sica y Qu�mica", "Biolog�a y Geolog�a", "Matem�ticas B", "Alem�n 2� Idioma", "Franc�s 2� Idioma", "Inform�tica");
	$it42 = array("(Bachillerato de Ciencias y Tecnolog�a - V�a de Ciencias e Ingenier�a)", "F�sica y Qu�mica", "Tecnolog�a", "Matem�ticas B", "Alem�n 2� Idioma", "Franc�s 2� Idioma", "Inform�tica", "Ed. Pl�stica y Visual");
	$it43 = array("(Bachillerato de Humanidades y Ciencias Sociales)", "Lat�n", "M�sica", "Matem�ticas A", "Matem�ticas B", "Alem�n 2� Idioma", "Franc�s 2� Idioma", "Inform�tica", "Ed. Pl�stica y Visual");
	$it44 = array("(Ciclos Formativos y Mundo Laboral)", "Inform�tica", "Ed. Pl�stica y Visual", "Matem�ticas A", "Alem�n 2� Idioma", "Franc�s 2� Idioma", "Tecnolog�a");

// Optativas 4� ESO	
	$opt41=array("Alem�n2_1" => "Alem�n 2� Idioma", "Franc�s2_1" => "Franc�s 2� Idioma", "Informatica_1" => "Inform�tica");
	$opt42=array("Alem�n2_2" => "Alem�n 2� Idioma", "Franc�s2_2" => "Franc�s 2� Idioma", "Informatica_2" => "Inform�tica", "EdPl�stica_2" => "Ed. Pl�stica y Visual");
	$opt43=array("Alem�n2_3" => "Alem�n 2� Idioma", "Franc�s2_3" => "Franc�s 2� Idioma", "Informatica_3" => "Inform�tica", "EdPl�stica_3" => "Ed. Pl�stica y Visual");
	$opt44=array("Alem�n2_4" => "Alem�n 2� Idioma", "Franc�s2_4" => "Franc�s 2� Idioma", "Tecnolog�a_4" => "Tecnolog�a");
?>